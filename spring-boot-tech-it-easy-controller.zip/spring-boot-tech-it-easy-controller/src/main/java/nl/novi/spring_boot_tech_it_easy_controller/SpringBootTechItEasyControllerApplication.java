package nl.novi.spring_boot_tech_it_easy_controller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootTechItEasyControllerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootTechItEasyControllerApplication.class, args);
	}

}
