package nl.novi.spring_boot_tech_it_easy_controller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootTechItEasyControllerApplicationTests {

	@Test
	void contextLoads() {
	}

}
